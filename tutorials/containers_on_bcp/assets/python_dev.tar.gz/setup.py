#!/usr/bin/env python

from distutils.core import setup

setup(name='pt_bench',
      version='1.0',
      description='pytorch benchmark',
      packages=['pt_bench'],
      install_requires=['torch'],
)
