#!/usr/bin/env python

import torch
import timeit
import pt_bench

x = torch.randn(100000, 1024*10, device='cuda')

t0 = timeit.Timer(
    stmt='batched_dot_mul_sum(x, x)',
    setup='from pt_bench import batched_dot_mul_sum',
    globals={'x': x})

t1 = timeit.Timer(
    stmt='batched_dot_bmm(x, x)',
    setup='from pt_bench import batched_dot_bmm',
    globals={'x': x})

# Ran each twice to show difference before/after warm-up
print(f'loaded pt_bench from {pt_bench.__file__}')
print(f'mul_sum(x, x):  {t0.timeit(100) / 100 * 1e6:>5.1f} us (warm-up)')
print(f'mul_sum(x, x):  {t0.timeit(100) / 100 * 1e6:>5.1f} us')
print(f'bmm(x, x):      {t1.timeit(100) / 100 * 1e6:>5.1f} us (warm-up)')
print(f'bmm(x, x):      {t1.timeit(100) / 100 * 1e6:>5.1f} us')
